//vars and actors
var box;
function startGame() {//donot delete this function
	myGameArea.start();// do not delete this line
	box = {
		x:0, 
		y:0,
		type:"rect",
		color:"red",
		width:30,
		height:30,
		col_type:"rect",
		col_w:30,
		col_h:30,
		is_gravity:false,
		gravity:0,
		grav_speed:0,
	};
	box = new draw(box);
}// do not delete this line
function updateGameArea() {//donot delete this function
	myGameArea.clear();//donot delete this line
	//rd = randInt(10, 300);
	//box.x = rd;
	//rt = randInt(10, 100);
	//box.y = rt;
	box.y = 40;
	box.x = 40;
	if (keyDown(40)) {
		log("hi");
	}
	update([box]);
}// do not delete this line