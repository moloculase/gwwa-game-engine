//settings===========
var bodyBackgroundColor = "white";
var screenScale = "auto";
var screenBackgroundColor = "black";
var screenBorderColor = "black";
var screenBorderWidth = 1 + "px";
var canvasMarginLeft = 0 + "px";
var canvasMarginRight = 0 + "px";
var canvasMarginDown = 0 + "px";
var canvasMarginUp = 0 + "px";
var screenBorderStyle = "solid";
var	titleName = "sample game run by the gwwa game engine";
var getMouseActions = true; //if true, gets vars such as mouses x or latmousedown y
var intervalSpeed = 20;//20
var isStorageAllowed = true; //if true it will allow for storing and saving data on users device